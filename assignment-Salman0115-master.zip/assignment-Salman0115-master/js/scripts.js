menuToggler.addEventListener('click', ev => {
  menu.classList.toggle('open');
});
